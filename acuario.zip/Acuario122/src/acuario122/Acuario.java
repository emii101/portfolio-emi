
package acuario122;

import java.util.ArrayList;
import java.util.List;


public class Acuario {
    private List<Animal> animales;

    public Acuario() {
        this.animales = new ArrayList<>();
    }
            
    public void agregarAnimal(Animal animal) throws Exception {
        for (Animal a : animales) {
            if (a.getNombre().equals(animal.getNombre()) && a.getHabitat().equals(animal.getHabitat())) {
                throw new Exception("Ya existe un animal con el mismo nombre y habitat.");
            }
        }
        animales.add(animal);
    }      
    
    public void mostrarAnimales(){
            if (animales.isEmpty()) {
            System.out.println("No hay animales registrados en el acuario.");
            return;
        }

        System.out.println("=== Lista de animales en el acuario ===");
        for (Animal animal : animales) {
            System.out.println(animal.toString());
        }
    }
    
    public void filtrarPorTipoAgua(TipoAgua tipo) {
        boolean encontrado = false;
        for (Animal animal : animales) {
            if (animal.getTipoAgua().equals(tipo)) {
                System.out.println(animal.toString());
                encontrado = true;
            }
        }

        if (!encontrado) {
            System.out.println("No se encontraron animales del tipo de agua: " + tipo);
        }
    }
    
    public void mostrarAnimalesPorTipo(String tipoAnimal){
        boolean encontrado = false;
        for (Animal animal : animales) {
            if (animal.getTipoAnimal().equals(tipoAnimal)) {
                System.out.println(animal.toString());
                encontrado = true;
            }
        }

        if (!encontrado) {
            System.out.println("No se encontraron animales del tipo: " + tipoAnimal);
        }
    }

}

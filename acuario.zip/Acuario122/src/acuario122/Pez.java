
package acuario122;


public class Pez extends Animal{
    private double longitudMaxima;

    public Pez(double longitudMaxima, String nombre, String tipoAnimal, String habitat, TipoAgua tipoAgua) {
        super(nombre, tipoAnimal, habitat, tipoAgua);
        this.longitudMaxima = longitudMaxima;
    }  

    @Override
    public void nadar() {
        System.out.println(getNombre() + " esta nadando alegremente.");
    }
    
    @Override
    public String toString() {
        return super.toString() +
            " | Tipo: Pez" +
            " | Longitud maxima: " + longitudMaxima + " cm";
    }
}

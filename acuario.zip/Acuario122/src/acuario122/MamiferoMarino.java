
package acuario122;


public class MamiferoMarino extends Animal{
    private double frecuenciaRespiracion;

    public MamiferoMarino(double frecuenciaRespiracion, String nombre, String tipoAnimal, String habitat, TipoAgua tipoAgua) {
        super(nombre, tipoAnimal, habitat, tipoAgua);
        this.frecuenciaRespiracion = frecuenciaRespiracion;
    }
    
    @Override
    public void nadar() {
        System.out.println(getNombre() + " esta nadando y saliendo a respirar.");
    }
    
    @Override
    public void buscarAlimento() {
        System.out.println(getNombre() + " esta buscando peces para alimentarse.");
    }
    
    @Override
    public String toString() {
        return super.toString() +
            " | Tipo: Mamifero Marino" +
            " | Frecuencia de respiracion: " + frecuenciaRespiracion + " seg";
    }
}

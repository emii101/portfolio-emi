
package acuario122;


public class Acuario122 {
    //Emiliano Guevara

    public static void main(String[] args) {
        Acuario acuario = new Acuario();
        Pez nemo = new Pez(15.0, "Nemo", "Pez","Tanque Tropical", TipoAgua.DULCE);
        Pez nemo2 = new Pez(12.0, "Nemo", "Pez", "Tanque Tropical", TipoAgua.DULCE);
        MamiferoMarino delfin = new MamiferoMarino(10.5, "Flipper", "Mamifero marino","Piscina Oceanica", TipoAgua.SALADA);
        Crustaceo cangrejo = new Crustaceo(8, "Crusty", "Crustaceo","Zona Rocosa", TipoAgua.SALADA);

        try {
            acuario.agregarAnimal(delfin);
            acuario.agregarAnimal(cangrejo);
            acuario.agregarAnimal(nemo);
            System.out.println("Animal/es agregado correctamente");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        
        // ejemplo 1
        try {
            acuario.agregarAnimal(nemo2);
            System.out.println("Animal/es agregado correctamente");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    
        //ejemplo 2
        acuario.mostrarAnimales();
        
        //ejemplo 3
        System.out.println("\n=== PRUEBAS DE ACCIONES ===");
        System.out.println("Intentos de nadar");
        delfin.nadar();
        nemo.nadar();
        cangrejo.nadar();
        System.out.println("Intentos de buscar alimento");
        delfin.buscarAlimento();
        nemo.buscarAlimento();
        cangrejo.buscarAlimento();
        
        //ejemplo 4
        System.out.println("\n=== FILTRADO POR TIPO DE AGUA ===");
        System.out.println("Animales de agua dulce:");
        acuario.filtrarPorTipoAgua(TipoAgua.DULCE);
        System.out.println("Animales de agua salada:");
        acuario.filtrarPorTipoAgua(TipoAgua.SALADA);
        
        //ejemplo 5
        System.out.println("\n=== FILTRADO POR TIPO DE ANIMAL ===");
        System.out.println("Peces:");
        acuario.mostrarAnimalesPorTipo("Pez");
        System.out.println("Mamiferos marinos:");
        acuario.mostrarAnimalesPorTipo("Mamifero marino");
        System.out.println("Crustaceos:");
        acuario.mostrarAnimalesPorTipo("Crustaceo");
        
    }
}
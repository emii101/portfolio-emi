
package acuario122;


public class Animal{
    private String nombre;
    private String tipoAnimal;
    private String habitat;
    private TipoAgua tipoAgua;

    public Animal(String nombre, String tipoAnimal, String habitat, TipoAgua tipoAgua) {
        this.nombre = nombre;
        this.tipoAnimal = tipoAnimal;
        this.habitat = habitat;
        this.tipoAgua = tipoAgua;
    }


    public TipoAgua getTipoAgua() {
        return tipoAgua;
    }

    public String getTipoAnimal() {
        return tipoAnimal;
    }

    public String getHabitat() {
        return habitat;
    }

    public String getNombre() {
        return nombre;
    }
    
    public void nadar() {
        System.out.println("El " + tipoAnimal + " no puede nadar.");
    }
    
    public void buscarAlimento(){
        System.out.println("El " + tipoAnimal + " no puede buscar alimento.");
    }
    
    @Override
    public String toString() {
        return   " | Nombre: " + nombre +
                " | Habitat: " + habitat +
               " | Tipo de agua: " + tipoAgua;
    }
}


package acuario122;


public class Crustaceo extends Animal{
    private int patas;

    public Crustaceo(int patas, String nombre, String tipoAnimal, String habitat, TipoAgua tipoAgua) {
        super(nombre, tipoAnimal, habitat, tipoAgua);
        this.patas = patas;
    }
    
    @Override
    public void buscarAlimento() {
        System.out.println(getNombre() + " esta buscando restos en el fondo del acuario.");
    }
    
    @Override
    public String toString() {
        return super.toString() +
            " | Tipo: Crustaceo" +
            " | Patas: " + patas;
    }
}
